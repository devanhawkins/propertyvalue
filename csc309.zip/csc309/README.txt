Installations (mainly for mac users)
=================================================================

Step 1: (installing apache)

type in http://localhost/ into your browser
If you see: It Works! then skip this step

If not type this in the terminal (mac users only)

sudo apachectl start

Reference:
(For macosx 10.8)
http://coolestguidesontheplanet.com/install-configure-apache-mysql-php-phpmyadmin-osx-10-8-mountain-lion/

(for windows)
http://httpd.apache.org/download.cgi

Step 2:

Install pip. Type this is in the terminal

sudo easy_install pip

(for window users on how to get pip)
http://stackoverflow.com/questions/4750806/how-to-install-pip-on-windows

Step 3:

Install mod_wsgi. Type this in the terminal

pip install mod_wsgi

Step 4:

Get latest version of python and mysql

https://www.python.org/downloads/
http://dev.mysql.com/downloads/mysql/

Step 5:

Now to install Django. Go to the project folder.

type this in the terminal 

pyvenv-3.4 djenv 

Now type this in the terminal. Make sure you're in the right directory where run309.sh is located

source run309.sh

Now type this in the terminal. Make sure u see (djenv) on the left side of the terminal.

./install309.sh

Congrats you now have Django


=================================================================================================
How to Run Project
=================================================================================================

Make sure you run source run309.sh whenever working this project. 

Go into CommunityFund folder

type in this in the terminal

python manage.py runserver

Now type this in to your browser to see our website (which is blank at the moment)

http://127.0.0.1:8000/

========================

AMAZON CREDIT CODE:

PC1V6JA33TA95G3

running amazon server:

//Note only i can use
ssh -i csc309key.pem ubuntu@52.10.253.147

