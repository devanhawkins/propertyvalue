from django.shortcuts import render
from .forms import ProfileForm
from .models import Interests
from .models import UserProfile
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect
from django.views.generic.detail import DetailView
from django.contrib.auth.models import User
# Create your views here.
@login_required
def RegisterProfile(request):

    error_msg = ""
    if request.method == 'POST':

        profile_form = ProfileForm( data=request.POST)
        if profile_form.is_valid():
            #create profile
            profile = profile_form.save(commit=False)
            profile.user=request.user
            profile.save()
            #redirect base on account type
            if profile.account == 'F':
                return redirect('project.views.funder')
            elif profile.account == 'I':
                return redirect('project.views.initiator')
        else:
            error_msg = "Make sure all fields are selected and birthday is in the format DD/MM/YY"
            return render(request,'project/profileregistration.html', {'profile_form': profile_form, 'error_msg':error_msg} )

    profile_form=ProfileForm() 
    return render(request,'project/profileregistration.html', {'profile_form': profile_form, 'error_msg':error_msg} )

# view to display a user's profile
def ProfilePage (request, user_id):
    profile=UserProfile.objects.get( user_id=user_id)
    user = User.objects.get(id=user_id)
    #interests = profile.interests.all
    return render(request, 'project/profilepage.html', {'profile': profile, 'user':user})

#view to edit profile
def editprofile (request):

    user = request.user
    profile = UserProfile.objects.get( user_id=user.id)
    msg = ""
    if request.method == 'POST':
        if request.POST['first_name'] == '' or request.POST['last_name'] == '' or request.POST['email'] == ''  or request.POST['about'] == '':
                msg = "one or fields are missing"
        else:
            user.first_name = request.POST['first_name']
            user.last_name = request.POST['last_name']
            user.email = request.POST['email']
            profile.about = request.POST['about']
            msg = "your changes have been saved!"
            profile.save()
                
    return render(request, 'project/editprofile.html', {'profile': profile, 'user':user, 'msg':msg})