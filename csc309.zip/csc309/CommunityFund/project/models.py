from django.db import models
from django.utils import timezone

#project model
class Project(models.Model):
    author = models.ForeignKey('auth.User')
    fullname = models.TextField(default="")
    email = models.TextField(default="")
    title = models.CharField(max_length=200)
    about = models.TextField()
    total_fund = models.IntegerField(default=0)
    created_date = models.DateTimeField(
            default=timezone.now)
    likes = models.IntegerField(default=0)
    dislikes= models.IntegerField(default=0)
    
#match model - match project with funders who wants to fund
class Match(models.Model):
    project = models.ForeignKey(Project)
    funder = models.ForeignKey('auth.User')
    funding = models.IntegerField()
    comment = models.TextField(default="")

