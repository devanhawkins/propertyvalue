from django.shortcuts import render, get_object_or_404
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.core.validators import validate_email
from django.core.exceptions import ValidationError
from django.contrib.auth import authenticate, login, logout
from django.shortcuts import redirect
from django.http import HttpResponseRedirect, HttpResponse
from .forms import UserForm, ProjectForm, MatchForm
from accounts.views import RegisterProfile
from accounts.models import UserProfile
from .models import Project, Match
from django.core.validators import validate_email
from django.core.exceptions import ValidationError

#from django.contrib.auth.decorators import login_required
# Create your views here.

#view to go to index page
def index(request):
	#return index page

	return render(request, 'project/index.html', {})

#view to logout
def logout (request):
    #log user out and return to index
    logout(request,'project/index.html')
    return render(request, 'project/index.html',{})

#view to login user
def login_user(request):

    login_error = ""
    if request.method == 'POST':
        user = authenticate(username=request.POST['username'], password=request.POST['password'])
        if user is not None:
            # the password verified for the user
            if user.is_active:		            	
                login(request, user)
                #get user profile and redirect based on account type
                profile = UserProfile.objects.get(user=request.user)
                if profile.account == 'F':
                    return redirect('project.views.funder')
                elif profile.account == 'I':
                    return redirect('project.views.initiator')
            else:
                login_error = "Account disabled"
        else:
            login_error = "Wrong password/username"
    
    return render(request, 'project/index.html', {'login_error':login_error})


#meant for testing purposes returns html that prints hello world
def blank(request):

		return render(request, 'project/blank.html', {})

#view to register user
def register(request):

    #boolean to check if user is registered
    registered = False

    error_msg = ""

    if request.method == 'POST':
        #missing fields
        if request.POST['first_name'] == '' or request.POST['last_name'] == '' or request.POST['email'] == '' or request.POST['password'] == '' or request.POST['username'] == '':
            error_msg = "One or more fields are missing"
            registered = True
            return render(request,'project/registration.html', {'registered': registered, 'error_msg':error_msg} )
        try:
            validate_email(request.POST['email'])

            User.objects.get(username=request.POST['username'])
            error = "Email already exist"
            error_bool = True
            #invalid email
        except ValidationError:
            registered = True
            error_msg = "Invalid Email"
            #user does not exist - so create a new one
        except User.DoesNotExist:
            user = User.objects.create_user(request.POST['username'], request.POST['email'], request.POST['password'])
            #user = authenticate(username=request.POST['username'], password=request.POST['password'])
            user.first_name = request.POST['first_name']
            user.last_name = request.POST['last_name']
            user.is_active = True
            user.save()
            new_user = authenticate(username=request.POST['username'],
                                        password=request.POST['password'])
            login(request, new_user)
            return redirect(RegisterProfile)

    return render(request,'project/registration.html', {'registered': registered, 'error_msg':error_msg} )


#view to go funder homepage
def funder(request):
    #get all projects - TODO filter base on interest
    projects = Project.objects.all()
    funded_proj = list()
    for p in projects:
        total = 0
        #get all funders that funded this project
        matches = Match.objects.filter(project=p)
        #get total fundings for this project
        for m in matches:
            total = total + m.funding
            if m.funder == request.user and p not in funded_proj:
                funded_proj.append(p)
        p.total_fund = total
        p.save()

    return render(request, 'project/funder.html', {'projects':projects, 'funded_proj':funded_proj})

#view to like a project
def likeProject(request, pk):
	idea = get_object_or_404(Project, pk=pk)
	idea.likes += 1
	idea.save()
	return redirect(funder)

#view to dislike project
@login_required
def dislikeProject (request, pk):
	idea = get_object_or_404(Project, pk=pk)
	idea.dislikes +=1
	idea.save()
	return redirect(funder)

#view to go to initiator homepage
def initiator(request):
    
    projects = Project.objects.all()
    myprojects = Project.objects.all().filter(author=request.user)
    return render(request, 'project/initiator.html',{'projects':projects, 'myprojects':myprojects})

#view to go to invidual project and add funds
def fund_project(request,pk):
    #get project
	project = get_object_or_404(Project, pk=pk)
	if request.method == "POST":
		form = MatchForm(request.POST)
		if form.is_valid():
            #collect funding for the project
			Match = form.save(commit=False)
			Match.funder = request.user
			Match.project = project
			Match.save()
			return redirect(funder)
	else:
		form = MatchForm()
        
	return render(request, 'project/fundproject.html', {'project':project,'form':form})

#cancel signup
def cancelsignup(request):

    user = request.user
    user.delete()
    return redirect(index)

#view to create project
def add_project(request):

    if request.method == "POST":
        form = ProjectForm(request.POST)
        if form.is_valid():
            #create and save project
            project = form.save(commit=False)
            user = request.user
            project.author = user
            project.fullname = user.get_full_name()
            project.email = user.email
            project.save()
            return redirect(initiator)
    else:
        form = ProjectForm()

    return render(request, 'project/add_project.html',{'form':form})

#view to display a project
def view_project(request,pk):
    #get project
    project = get_object_or_404(Project, pk=pk)
    matches = Match.objects.all().filter(project=project)   
    return render(request, 'project/view_project.html', {'project':project, 'matches':matches})

#view to go homepage depending on account type
def home(request):

    user = request.user
    profile = UserProfile.objects.get( user_id=user.id)
    if profile.account == 'F':
        return redirect('project.views.funder')
    elif profile.account == 'I':
        return redirect('project.views.initiator')
