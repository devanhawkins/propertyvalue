# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('project', '0002_auto_20150311_2104'),
    ]

    operations = [
        migrations.AddField(
            model_name='project',
            name='email',
            field=models.TextField(default=b''),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='project',
            name='fullname',
            field=models.TextField(default=b''),
            preserve_default=True,
        ),
    ]
