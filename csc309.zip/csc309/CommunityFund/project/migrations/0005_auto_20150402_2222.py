# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('project', '0004_match_comment'),
    ]

    operations = [
        migrations.AddField(
            model_name='project',
            name='dislikes',
            field=models.IntegerField(default=0),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='project',
            name='likes',
            field=models.IntegerField(default=0),
            preserve_default=True,
        ),
    ]
