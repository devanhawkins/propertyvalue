# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('project', '0003_auto_20150402_0146'),
    ]

    operations = [
        migrations.AddField(
            model_name='match',
            name='comment',
            field=models.TextField(default=b''),
            preserve_default=True,
        ),
    ]
