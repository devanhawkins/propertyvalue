#!/bin/bash  

#pyvenv-3.4 djenv          # create django virtual env
source djenv/bin/activate # activate it
