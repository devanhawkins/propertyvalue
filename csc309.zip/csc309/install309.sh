#!/bin/bash  

pip install django django-extensions
pip3 install mysql-connector-python --allow-external mysql-connector-python

